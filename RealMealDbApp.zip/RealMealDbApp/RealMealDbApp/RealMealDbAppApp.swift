//
//  RealMealDbAppApp.swift
//  RealMealDbApp
//
//  Created by Shujat Ali on 06/11/2023.
//

import SwiftUI

@main
struct RealMealDbAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
